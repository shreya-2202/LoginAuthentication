const loginForm = document.getElementById("login-form");
const loginButton = document.getElementById("submit");
const loginErrorMsg = document.getElementById("login-error-msg");


loginButton.addEventListener("click", (e) => {
    e.preventDefault();
    const username = loginForm.uname.value;
    const password = loginForm.psw.value;
    console.log(username, password)

    if (username === "shreya@gmail.com" && password === "shreya123") {
        alert("You have Successfully Logged In!!");
        location.reload();
    } else {
        loginErrorMsg.style.opacity = 1;
       
    }
});